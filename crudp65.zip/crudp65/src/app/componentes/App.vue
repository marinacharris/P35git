<template>
<div>
    <nav class="navbar navbar-light bg-light">
        <a href="/" class="navbar-brand">Aplicación pila MEVN</a>
    </nav>
    <div class="container">
        <div class="row pt-5">
            <div class="col-md-5">
                <div class="card">
                    <div class="card-body">
                        <form @submit.prevent="enviarProducto">
                            <div class="form-group pt-2">
                                <input type="text"
                                placeholder="Inserte el código"
                                class="form-control"
                                v-model="task.codigo">
                            </div>
                            <div class="form-group pt-2">
                                <textarea cols="30" rows="5" 
                                class="form-control"
                                placeholder="Inserte la descripción"
                                v-model="task.descripcion">
                                </textarea>
                            </div>
                            <div class="form-group pt-2 pb-2">
                                <input type="number"
                                placeholder="Inserte el precio"
                                class="form-control"
                                v-model="task.precio">
                            </div>
                            <template v-if="edit === false">
                                <button class="btn btn-primary">
                                GUARDAR
                                </button>
                            </template>
                            <template v-else>
                                <button class="btn btn-primary">
                                ACTUALIZAR
                                </button>
                            </template>

                            
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-7">
                <table class="table table-bordered">
                    <thead>
                        <th>Código</th>
                        <th>Descripción</th>
                        <th>Precio</th>
                    </thead>
                    <tbody>
                        <tr v-for="task of tasks">
                            <td>{{task.codigo}}</td>
                            <td>{{task.descripcion}}</td>
                            <td>{{task.precio}}</td>
                            <td>
                                <button @click="deleteProducto(task._id)"
                                class="btn btn-info">
                                Borrar
                                </button>
                                <button @click="updateProducto(task._id)"
                                class="btn btn-success">
                                Actualizar
                                </button>
                            </td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>  
</template>

<script>
class task{
    constructor(codigo,descripcion, precio){
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.precio = precio;
    }
}
export default{
    data(){
        return{
            task: new task(),
            tasks: [],
            edit: false,
            tareaEdit: ''
            }
        },
    created(){
        this.getProducto();
    },
    methods:{
        enviarProducto(){
            if(this.edit === false){
                this.addProducto();
            }else{
                fetch('/tasks/'+ this.tareaEdit,{
                    method: 'PUT',
                    body: JSON.stringify(this.task),
                    headers: {
                        'Accept':'application/json',
                        'Content-type': 'application/json'
                    }
                })
                .then(res => res.json())
                .then(data => this.getProducto())
                .then(this.edit = false)
                this.task = new task();
            }
        },
        addProducto(){
            console.log(this.task);
            fetch('/tasks',{
                method: 'POST',
                body: JSON.stringify(this.task),
                headers:{
                    'Accept': 'application/json',
                    'Content-type': 'application/json'
                }
            }).then(res => res.json())
            .then(data => this.getProducto())
            this.task = new task();
        },
        getProducto(){ 
            fetch('/tasks')
            .then(res =>res.json())
            .then(data =>{
                this.tasks = data
                console.log(this.tasks)
            })
        },
        deleteProducto(id){ 
            fetch('/tasks/'+id,{
                method: 'DELETE',
                headers: {
                    'Accept': 'application/json',
                    'Content-type': 'application/json'
                }
            }).then(res => res.json)
            .then(data => this.getProducto())
            
            //console.log(id);
        },
        updateProducto(id){
            fetch('tasks/'+id)
            .then(res => res.json())
            .then(data => {
               this.task = new task(data.codigo, data.descripcion, data.precio)
               this.edit = true
               this.tareaEdit = data._id
            });
            //console.log(id)
        }
    }
}
</script>